# Flood Segmentation App

Upload satellite images and get flood condition labels using a trained UNet model.
